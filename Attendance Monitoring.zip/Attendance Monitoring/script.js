let on = false;
let off = true;
let textbox = document.querySelector('#activate').disabled = off;

function edit(){

  document.querySelector("#edit").value = "Done";
  textbox = document.querySelector('#activate').disabled = on;

}
